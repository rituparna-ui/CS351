import boto3 as boto
import time
import webbrowser

###############################################################################################################
# Launch RDS Instance

client = boto.client('rds')

response = client.create_db_instance(
    DBName='feedback',
    AllocatedStorage=5,
    DBInstanceClass='db.t2.micro',
    DBInstanceIdentifier='mymysqlinstance',
    DBParameterGroupName='connectphp',
    Engine='MySQL',
    MasterUserPassword='thisismypassword',
    MasterUsername='myuser',
)
print("RDS MySQL instance created.")
print("Waiting for RDS instance to come online.")

waiter = client.get_waiter('db_instance_available')
waiter.wait(DBInstanceIdentifier='mymysqlinstance')
print("RDS instance is online now.")

response = client.describe_db_instances(
    DBInstanceIdentifier='mymysqlinstance',
)

endpoint = response['DBInstances'][0]['Endpoint']['Address']

print("RDS DNS: %s" %endpoint)


#################################################################################################################
# Launch EC-2 Instance

ec2 = boto.resource('ec2')
ec2Client = boto.client('ec2')

# Security group
security_group_id = "sg-061c8162"

# User data
user_data = """
    #!/bin/bash
    sudo yum update -y
    sudo yum install -y httpd24 php56 php56-mysqlnd
    sudo service httpd start   
    mkdir ~/.aws && cd ~/.aws
    touch credentials && touch config
    echo "[default]" > credentials
    echo "AWS_ACCESS_KEY_ID = AKIAUSS2YTS4BF365HKE" >> credentials
    echo "AWS_SECRET_ACCESS_KEY = 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" >> credentials
    echo "[default]" > config
    echo "output = json" >> config
    echo "region = ap-south-1" >> config
    aws s3 sync s3://customer-feedback-management ~/../../var/www/html 
    echo '<?php
        define("DB_SERVER", \"""" + endpoint + """:3306");
        define("DB_USER", "myuser");
        define("DB_PASSWORD", "thisismypassword");
        define("DB_NAME", "feedback");

        $conn = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);

        if($conn->connect_error){
            die("Connection error: ".$conn->connect_error);
        }

    ?>' > ~/../../var/www/html/config.php
"""

# Create new instance
instances = ec2.create_instances(
    ImageId='ami-0a780d5bac870126a',
    MinCount=1,
    MaxCount=1,
    InstanceType='t2.micro',
    SecurityGroupIds=[security_group_id],
    KeyName='assignment',
    UserData=user_data
)

instance_id = instances[0].id
print("Launching new  EC2 instance")

# Wait for instance to be into running state
waiter = ec2Client.get_waiter('instance_running')
waiter.wait(InstanceIds=[instance_id])
print("Instance running now, instance id : %s" %instance_id)

# Fetch instance details
reservations = ec2Client.describe_instances()["Reservations"]

# Open DNS in browser
for reservation in reservations:
    instance = reservation["Instances"][0]
    if instance["InstanceId"] == instance_id:
        dns = instance["PublicDnsName"]
        print("Public DNS : %s" % dns)
        print("Waiting 40 sec for files to get loaded and Apache server to start")
        time.sleep(40)  #sleep for 4 sec before opening in browser
        print("Opening browser")
        webbrowser.open(dns)



